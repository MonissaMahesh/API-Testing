package com.paymentapi.endpoints;

public class APIConstants {

}
