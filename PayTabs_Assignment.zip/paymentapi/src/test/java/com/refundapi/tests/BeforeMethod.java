package com.refundapi.tests;

public @interface BeforeMethod {

}
